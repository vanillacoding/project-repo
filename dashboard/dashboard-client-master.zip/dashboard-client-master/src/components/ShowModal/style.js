export const modal = {
  visible: { opacity: 1 },
  hidden: { opacity: 0 }
};
